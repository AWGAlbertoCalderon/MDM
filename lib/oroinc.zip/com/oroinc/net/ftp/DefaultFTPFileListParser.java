// FrontEnd Plus for JAD
// DeCompiled : DefaultFTPFileListParser.class

package com.oroinc.net.ftp;

import java.io.*;
import java.util.Calendar;
import java.util.Vector;

// Referenced classes of package com.oroinc.net.ftp:
//            FTPFile, FTPFileListParser

public final class DefaultFTPFileListParser
    implements FTPFileListParser
{

    private int __charArrayToInt(char ac[], int i, int j)
    {
        int k = 0;
        for(int l = 1; j-- > i; l *= 10)
            k += l * (ac[j] - 48);

        return k;
    }

    private long __charArrayToLong(char ac[], int i, int j)
    {
        long l = 0L;
        for(long l1 = 1L; j-- > i; l1 *= 10L)
            l += l1 * (long)(ac[j] - 48);

        return l;
    }

    private int __skipWhitespace(char ac[], int i)
    {
        for(; i < ac.length && Character.isWhitespace(ac[i]); i++);
        return i;
    }

    private int __skipDigits(char ac[], int i)
    {
        for(; i < ac.length && Character.isDigit(ac[i]); i++);
        return i;
    }

    private int __skipNonWhitespace(char ac[], int i)
    {
        for(; i < ac.length && !Character.isWhitespace(ac[i]); i++);
        return i;
    }

    private int __skipNonWhitespaceToLower(char ac[], int i)
    {
        for(; i < ac.length && !Character.isWhitespace(ac[i]); i++)
            ac[i] = Character.toLowerCase(ac[i]);

        return i;
    }

    public FTPFile parseFTPEntry(String s)
    {
        FTPFile ftpfile;
        try
        {
            char ac[] = s.toCharArray();
            ftpfile = new FTPFile();
            ftpfile.setRawListing(s);
            boolean flag = ac[0] == 'b' || ac[0] == 'c';
            byte byte0;
            switch(ac[0])
            {
            case 100: // 'd'
                byte0 = 1;
                break;

            case 108: // 'l'
                byte0 = 2;
                break;

            default:
                byte0 = 0;
                break;
            }
            ftpfile.setType(byte0);
            int i = 0;
            int j = 1;
            for(; i < 3; i++)
            {
                ftpfile.setPermission(i, 0, ac[j++] != '-');
                ftpfile.setPermission(i, 1, ac[j++] != '-');
                ftpfile.setPermission(i, 2, ac[j++] != '-');
            }

            int l1;
            for(l1 = j; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
            j = l1;
            for(l1 = j; l1 < ac.length && Character.isDigit(ac[l1]); l1++);
            int k = l1;
            ftpfile.setHardLinkCount(__charArrayToInt(ac, j, k));
            for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
            j = l1;
            for(l1 = j; l1 < ac.length && !Character.isWhitespace(ac[l1]); l1++);
            k = l1;
            ftpfile.setUser(new String(ac, j, k - j));
            for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
            j = l1;
            for(l1 = j; l1 < ac.length && !Character.isWhitespace(ac[l1]); l1++);
            k = l1;
            ftpfile.setGroup(new String(ac, j, k - j));
            if(flag)
            {
                for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
                j = l1;
                for(l1 = j; l1 < ac.length && !Character.isWhitespace(ac[l1]); l1++);
                k = l1;
                for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
                j = l1;
                for(l1 = j; l1 < ac.length && !Character.isWhitespace(ac[l1]); l1++);
                k = l1;
            } else
            {
                for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
                j = l1;
                for(l1 = j; l1 < ac.length && Character.isDigit(ac[l1]); l1++);
                k = l1;
                ftpfile.setSize(__charArrayToLong(ac, j, k));
            }
            for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
            j = l1;
            for(l1 = j; l1 < ac.length && !Character.isWhitespace(ac[l1]); l1++)
                ac[l1] = Character.toLowerCase(ac[l1]);

            k = l1;
            byte byte1;
            switch(ac[j])
            {
            case 97: // 'a'
                if(ac[k - 1] == 'r')
                    byte1 = 3;
                else
                    byte1 = 7;
                break;

            case 100: // 'd'
                byte1 = 11;
                break;

            case 102: // 'f'
                byte1 = 1;
                break;

            case 106: // 'j'
                if(ac[k - 1] == 'l')
                {
                    byte1 = 6;
                    break;
                }
                if(ac[j + 1] == 'a')
                    byte1 = 0;
                else
                    byte1 = 5;
                break;

            case 109: // 'm'
                if(ac[k - 1] == 'y')
                    byte1 = 4;
                else
                    byte1 = 2;
                break;

            case 110: // 'n'
                byte1 = 10;
                break;

            case 111: // 'o'
                byte1 = 9;
                break;

            case 115: // 's'
                byte1 = 8;
                break;

            default:
                byte1 = 0;
                break;
            }
            for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
            j = l1;
            for(l1 = j; l1 < ac.length && Character.isDigit(ac[l1]); l1++);
            k = l1;
            i = __charArrayToInt(ac, j, k);
            for(l1 = k; l1 < ac.length && Character.isWhitespace(ac[l1]); l1++);
            j = l1;
            for(l1 = j; l1 < ac.length && Character.isDigit(ac[l1]); l1++);
            k = l1;
            Calendar calendar = Calendar.getInstance();
            try
            {
                int i1;
                int j1;
                int k1;
                if(ac[k] == ':')
                {
                    i1 = calendar.get(1);
                    j1 = calendar.get(2);
                    if(j1 < byte1)
                        i1--;
                    j1 = __charArrayToInt(ac, j, k);
                    j = k + 1;
                    for(l1 = j; l1 < ac.length && Character.isDigit(ac[l1]); l1++);
                    k = l1;
                    k1 = __charArrayToInt(ac, j, k);
                } else
                {
                    j1 = k1 = -1;
                    i1 = __charArrayToInt(ac, j, k);
                }
                calendar.clear();
                calendar.set(1, i1);
                calendar.set(2, byte1);
                calendar.set(5, i);
                if(j1 != -1)
                {
                    calendar.set(10, j1);
                    calendar.set(12, k1);
                }
            }
            catch(IllegalArgumentException _ex) { }
            ftpfile.setTimestamp(calendar);
            j = k + 1;
            for(l1 = j; l1 < ac.length && !Character.isWhitespace(ac[l1]); l1++);
            k = l1;
            if(k >= ac.length)
            {
                ftpfile.setName(new String(ac, j, k - j));
                return ftpfile;
            }
            String s1 = new String(ac, j, ac.length - j);
            if(byte0 == 2)
            {
                int l = s1.indexOf(" -> ");
                if(l == -1)
                {
                    ftpfile.setName(s1);
                    return ftpfile;
                } else
                {
                    ftpfile.setName(s1.substring(0, l));
                    ftpfile.setLink(s1.substring(l + 4));
                    return ftpfile;
                }
            }
            ftpfile.setName(s1);
        }
        catch(ArrayIndexOutOfBoundsException _ex)
        {
            return null;
        }
        catch(StringIndexOutOfBoundsException _ex)
        {
            return null;
        }
        return ftpfile;
    }

    public FTPFile[] parseFileList(InputStream inputstream)
        throws IOException
    {
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream));
        String s;
        Vector vector;
        if((s = bufferedreader.readLine()) == null)
        {
            vector = null;
        } else
        {
            vector = new Vector();
            if(s.toLowerCase().startsWith("total"))
            {
                s = bufferedreader.readLine();
            } else
            {
                FTPFile ftpfile;
                if((ftpfile = parseFTPEntry(s)) != null)
                    vector.addElement(ftpfile);
                s = bufferedreader.readLine();
            }
            for(; s != null; s = bufferedreader.readLine())
            {
                FTPFile ftpfile1;
                if(s.length() == 0 || (ftpfile1 = parseFTPEntry(s)) == null)
                {
                    vector = null;
                    break;
                }
                vector.addElement(ftpfile1);
            }

        }
        if(s != null)
            while((s = bufferedreader.readLine()) != null) ;
        bufferedreader.close();
        if(vector != null)
        {
            FTPFile aftpfile[] = new FTPFile[vector.size()];
            if(aftpfile.length > 0)
                vector.copyInto(aftpfile);
            return aftpfile;
        } else
        {
            return null;
        }
    }

    public DefaultFTPFileListParser()
    {
    }
}
